package com.customlistfragment.customlistfragment_;

/**
 * Created by trident on 9/6/16.
 */
public class ListItems {
    public int icon;
    public String title;
    public ListItems(){
        super();
    }

    public ListItems(int icon, String title) {
        super();
        this.icon = icon;
        this.title = title;
    }
}
